namespace productInformation {


    export interface Users {

        //id:number;
        name: string;
        //description:string;
        password: string;
    }

    export interface productInfo {

        image: string;
        name: string;
        label: string;
        price: number;
        status: string;
        description: string;
        id: number;
        key: string;
    }

    export interface showProduct {
        image: string;
        label: string;
        id: number;
    }
}