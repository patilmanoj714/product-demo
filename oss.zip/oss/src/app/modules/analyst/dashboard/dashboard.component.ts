import { Router } from '@angular/router';
import { showProduct } from './../../../model/user.model';
import { ProductsService } from './../../../services/products.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  showProduct:showProduct[];

  constructor(private producService:ProductsService, private router:Router) { }

  ngOnInit() {
  }

  
}
