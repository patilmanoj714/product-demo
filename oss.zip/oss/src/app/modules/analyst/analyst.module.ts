import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { NgModule, Component } from '@angular/core';
import { CommonModule } from '@angular/common';

const analystApp: Routes = [
  {
    path: 'dashboard',
    component: DashboardComponent
  }
]
@NgModule({
  declarations: [
    DashboardComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(analystApp)
  ]
})
export class AnalystModule { }
