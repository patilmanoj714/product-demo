import { Routes, RouterModule } from '@angular/router';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { ProductCategoryComponent } from './product-category/product-category.component';
import { ProductListComponent } from './product-list/product-list.component';
import { ProductComponent } from './product/product.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { NgModule, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';

const userApp: Routes = [
  {
    path: 'dashboard',
    component: DashboardComponent
  },
  {
    path: 'product/:ProductName',
    component: ProductComponent
  },
  {
    path: 'product-list',
    component: ProductListComponent
  },
  {
    path: 'product-details/:ProductName',
    component: ProductDetailsComponent
  },
  {
    path: 'product-category',
    component: ProductCategoryComponent
  }
]

@NgModule({
  declarations: [
    DashboardComponent,
    ProductComponent,
    ProductListComponent,
    ProductDetailsComponent,
    ProductCategoryComponent
  ],
  imports: [
    CommonModule,
    HttpClientModule,
    RouterModule.forChild(userApp)
  ],
  exports: [
    ProductComponent,
    ProductDetailsComponent
  ]



})
export class UserModule {
}
