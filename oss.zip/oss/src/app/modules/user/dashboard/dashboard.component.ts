import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
//import { showProduct, productInfo } from './../../../model/user.model';
import { ProductsService } from '@os-service/products.service';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  showProduct: productInformation.productInfo[];

  constructor(private productService: ProductsService, private router: Router) { }

  ngOnInit() {
    this.getAllProduct();
  }

  getAllProduct() {
    this.productService.getAllDisplayProduct().subscribe(
      (product) => {
        this.showProduct = product;
      }
    )
  }
}
