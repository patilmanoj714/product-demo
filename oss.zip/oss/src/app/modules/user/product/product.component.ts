//import { Users, productInfo } from './../../../model/user.model';
import { ProductsService } from '@os-service/products.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {


  hpLaptop: string;
  dellLaptop: string;
  sonyLaptop: string;
  alinewareLaptop: string;
  allProducts: productInformation.productInfo[];
  imageHeight = 100;
  imageWidth = 100;
  isButtonShow = false;
  title = 'Hide';
  pro
  constructor(private productService: ProductsService, private router: ActivatedRoute) { }

  ngOnInit() {

    let productName;
    this.router.params.subscribe(
      (param) => {
        productName = param['ProductName'];
        console.log(productName);
      });
    this.getAllProductsByProductName(productName);
  }

  getAllProductsByProductName(productName: string) {
    if (productName === 'laptop') {
      this.productService.getAllLaptopProduct().subscribe(
        (product) => {
          this.allProducts = product;
          console.table(product);
        });
    }
    if (productName === 'desktop') {
      this.productService.getAllDesktopProduct().subscribe(
        (product) => {
          this.allProducts = product;
          console.table(product);
        });
    }
    if (productName === 'mobile') {
      this.productService.getAllMobileProduct().subscribe(
        (product) => {
          this.allProducts = product;
          console.table(product);
        });
    }
  }

  showAndHide(title) {
    if (title === 'Hide') {
      this.title = 'Show';
      this.isButtonShow = true;
    }
    if (title === 'Show') {
      this.title = 'Hide';
      this.isButtonShow = false;
    }
  }
}
