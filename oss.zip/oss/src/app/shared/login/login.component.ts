import { Router } from '@angular/router';
//import { Users } from './../../model/user.model';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {


  user: productInformation.Users = {
    //id:'',
    name: '',
    password: '',
    //description:'',
  };
  constructor(private router: Router) { }

  ngOnInit() {
  }

  userLogin(user: productInformation.Users) {

    if (user.name == 'user' && user.password == 'user') {
      this.router.navigateByUrl('role/user/dashboard');
    }
    else if (user.name == 'analyst' && user.password == 'analyst') {
      this.router.navigateByUrl('role/analyst/dashboard');
    }
    else {
      this.router.navigateByUrl('login');
    }

  }
}
