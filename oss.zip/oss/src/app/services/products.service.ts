//import { showProduct, productInfo } from './../model/user.model';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  mockData = "http://localhost:3000";

  allProduct: productInformation.showProduct;

  constructor(private http: HttpClient) { }

  getAllDisplayProduct(): Observable<productInformation.showProduct[]> {
    return this.http.get<productInformation.showProduct[]>(this.mockData + '/' + 'productCategory');
  }

  getAllLaptopProduct(): Observable<productInformation.productInfo[]> {
    return this.http.get<productInformation.productInfo[]>(this.mockData + '/' + 'Laptop');
  }

  getAllDesktopProduct(): Observable<productInformation.productInfo[]> {
    return this.http.get<productInformation.productInfo[]>(this.mockData + '/' + 'Desktop');
  }

  getAllMobileProduct(): Observable<productInformation.productInfo[]> {
    return this.http.get<productInformation.productInfo[]>(this.mockData + '/' + 'Mobile');
  }

}
