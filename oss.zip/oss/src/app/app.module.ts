//import { DashboardComponent } from './modules/analyst/dashboard/dashboard.component';
//import { DashboardComponent } from './modules/user/dashboard/dashboard.component';
import { ProductsService } from '@os-service/products.service';
import { AnalystModule } from './modules/analyst/analyst.module';
import { UserModule } from './modules/user/user.module';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component } from '@angular/core';

import { AppComponent } from './app.component';
import { LoginComponent } from './shared/login/login.component';
import { HeaderComponent } from './shared/header/header.component';
import { FooterComponent } from './shared/footer/footer.component';
import { RoleComponent } from './shared/role/role.component';
import { PagenotfoundComponent } from './shared/pagenotfound/pagenotfound.component';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';


const appRoute: Routes = [
  {
    path: '', redirectTo: 'login', pathMatch: 'full'
  },
  {
    path: 'login', component: LoginComponent
  },
  {
    path: 'role', component: RoleComponent,
    children: [
      {
        path: 'user', loadChildren: () => UserModule
      },
      {
        path: 'analyst', loadChildren: () => AnalystModule
      }
    ]
  },
  {
    path: '**',
    component: PagenotfoundComponent
  }
]

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HeaderComponent,
    FooterComponent,
    RoleComponent,
    PagenotfoundComponent
  ],
  imports: [
    BrowserModule,
    UserModule,
    AnalystModule,
    FormsModule,
    RouterModule.forRoot(appRoute)
  ],
  providers: [ProductsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
